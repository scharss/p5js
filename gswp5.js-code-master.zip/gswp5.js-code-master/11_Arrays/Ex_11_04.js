var x = [];  // Declare the array

function setup() {
  createCanvas(200, 200);
  x[0] = 12;       // Assign the first value
  x[1] = 2;        // Assign the second value
}