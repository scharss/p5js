var x = [12, 2]; // Declare and assign

function setup() {
  createCanvas(200, 200);
}