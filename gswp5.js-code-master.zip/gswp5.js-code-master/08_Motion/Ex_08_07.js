function draw() {
  var r = random(0, mouseX);
  print(r);
}