function draw() {
  var timer = millis();
  print(timer);
}