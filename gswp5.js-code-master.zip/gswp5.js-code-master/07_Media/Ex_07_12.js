function setup() {
  createCanvas(480, 120);
  textFont("Source Code Pro");
  fill(0);
  stroke(255);
}

function draw() {
  background(102);
  textSize(28);
  text("one small step for man...", 25, 60);
  textSize(16);
  text("one small step for man...", 27, 90);
}