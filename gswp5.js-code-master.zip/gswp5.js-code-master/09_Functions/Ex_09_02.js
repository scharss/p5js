function setup() {
  print("Ready to roll!");
  var d1 = 1 + int(random(20));
  print("Rolling... " + d1);
  var d2 = 1 + int(random(20));
  print("Rolling... " + d2);
  var d3 = 1 + int(random(6));
  print("Rolling... " + d3);
  print("Finished.");
}