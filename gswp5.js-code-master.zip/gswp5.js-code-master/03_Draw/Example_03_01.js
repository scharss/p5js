function setup() {
  createCanvas(800, 600);
}