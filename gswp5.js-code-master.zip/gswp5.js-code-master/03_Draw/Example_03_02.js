function setup() {
  createCanvas(480, 120);
}

function draw() {
  background(204);
  point(240, 60);
}