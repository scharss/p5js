function draw() {
  // Displays the frame count to the Console
  print("I’m drawing");
  print(frameCount);
}