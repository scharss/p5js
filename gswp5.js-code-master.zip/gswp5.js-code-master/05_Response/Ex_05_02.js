function setup() {
  print("I’m starting");
}

function draw() {
  print("I’m running");
}